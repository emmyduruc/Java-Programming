
public interface Playable {
    void help();
    void back();
    void quit();
    void goNorth();
    void goSouth();
    void goWest();
    void goEast();
    void collectWeapon();
    void collectLetter();
}
