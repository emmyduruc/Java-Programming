import javax.swing.*;
import java.util.HashSet;
import java.util.Stack;
 
  /**
 *  This class is the main class of the "SAVIOUR" application. 
 *  "SAVIOUR" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 * Modified by Emmanuel Duru
 */

public class Game 
{

    private static Game game;
    private Player player;
    Room firstRoom;

    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        createRooms();
    }

    public static Game getGameInstance()
    {
        if(game==null){
            game= new Game();
        }
        return game;
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
        Room idaho, ohio, florida, california, maryland, texas, washington;
      
        
        Item weapon1 = new Item("AK 47");
        Item letter = new Item("classified information (letter)");
        
        // create the rooms
        idaho = new Room("in the starting point of the game");

        ohio = new Room("in ohio to take a letter to be delivered to the president in washington.\n.saviour: OH! sounds like i have got to do the bad guy thing \nto make a successful delivery ha!ha!ha");
        ohio.placeItem(letter);

        florida = new Room("in God we trust city(florida) \n and will be taking a route (california) \nwhere most bad guys dwell so take a weapon \nfor self-defense you might encounter some bad guys on your way");
        florida.placeItem(weapon1);

        california = new Room("to be very careful,saviour: ha!ha! i fear no man!! \nwhoever that shows up takes the first bullet, ARO MATE!!!");
        maryland = new Room("apprehended ha!ha!ha! get me the letter \nand kill the bastard!,now go back and try again");
        texas = new Room("in a beautiful and peaceful city, \nsaviour: sure i am already getting to the president");
        washington = new Room("at the office of the president, now you delivered the letter.\nMission Accomplished!!!\nQuit and Restart Game");
        
        // initialise room exits
        idaho.setExit("east",ohio);
        
        ohio.setExit("west", idaho);
        ohio.setExit("east", florida);
        
        florida.setExit("west", ohio);
        florida.setExit("south", california);
        
        california.setExit("north", florida);
        california.setExit("west", texas);
        california.setExit("east", maryland);
        
        maryland.setExit("west", california);
        
        texas.setExit("east", california);
        texas.setExit("south", washington);
        
        washington.setExit("north", texas);

        firstRoom = idaho;
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public Room start(GuiGame guiGame)
    {
        welcomePlayer(guiGame);
        return firstRoom;
    }

    public Room quit(GuiGame guiGame)
    {
        sendFarewell(guiGame);
        return firstRoom; // after quit take user back to first room!
    }

    public void welcomePlayer(GuiGame guiGame){
        String message = "Welcome to the World of Zuul!\n"+"World of Zuul is a new, incredibly boring adventure game.\n"+"Type 'help' if you need help.\n"+firstRoom.getLongDescription();
        guiGame.displayTextArea.setText(message);
    }

    public void sendFarewell(GuiGame guiGame){
        guiGame.displayTextArea.setText("Thank you for playing.  Good bye.\n"+firstRoom.getLongDescription());
    }

}
