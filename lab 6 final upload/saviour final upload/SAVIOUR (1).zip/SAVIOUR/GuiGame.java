import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GuiGame extends JFrame {

    private Player player;
    private static GuiGame guiGame;

    //GUI Labels
    protected JTextArea displayTextArea;
    private JButton goNorthButton;
    private JButton goWestButton;
    private JButton goEastButton;
    private JButton goSouthButton;

    private JButton collectWeaponButton;
    private JButton collectLetterButton;


    public GuiGame(Player player){
        this.player = player;
    }

    public static GuiGame getGuiGameInstance(Player player)
    {
        if(guiGame==null){
            guiGame= new GuiGame(player);
        }
        return guiGame;
    }

    public void makeGuiVisible(){
        //GUI Part
        this.createGameFrame();
    }

    private void createGameFrame()
    {
        JPanel contentPane = (JPanel) getContentPane();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));

        makeMenuBar();

        contentPane.setLayout(new BorderLayout(8, 8));

        displayTextArea = new JTextArea();
        contentPane.add(displayTextArea, BorderLayout.CENTER);


        JPanel upperToolbar = new JPanel();
        upperToolbar.setLayout(new GridLayout(1, 0));

        collectWeaponButton = new JButton("Collect Weapon");
        collectWeaponButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player.collectWeapon();
            }
        });
        upperToolbar.add(collectWeaponButton);

        collectLetterButton = new JButton("Collect Letter");
        collectLetterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player.collectLetter();
            }
        });
        upperToolbar.add(collectLetterButton);

        JPanel upperFlow = new JPanel();
        upperFlow.add(upperToolbar);

        contentPane.add(upperFlow, BorderLayout.NORTH);

        JPanel sideToolbar = new JPanel();
        sideToolbar.setLayout(new GridLayout(0, 1));

        goNorthButton = new JButton("Go North");
        goNorthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player.goNorth();
            }
        });
        sideToolbar.add(goNorthButton);

        goWestButton = new JButton("Go West");
        goWestButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player.goWest();
            }
        });
        sideToolbar.add(goWestButton);

        goEastButton = new JButton("Go East");
        goEastButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player.goEast();
            }
        });
        sideToolbar.add(goEastButton);

        goSouthButton = new JButton("Go South");
        goSouthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player.goSouth();
            }
        });
        sideToolbar.add(goSouthButton);

        JPanel sideFlow = new JPanel();
        sideFlow.add(sideToolbar);

        contentPane.add(sideFlow, BorderLayout.EAST);


        pack();
        setVisible(true);
    }

    private void makeMenuBar()
    {
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu menu;
        JMenuItem item1, item2, item3;

        menu = new JMenu("User Controls");
        menuBar.add(menu);

        item1 = new JMenuItem("Back");
        item1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player.back();
            }
        });
        menu.add(item1);

        item2 = new JMenuItem("Help");
        item2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player.help();
            }
        });
        menu.add(item2);


        item3 = new JMenuItem("Quit");
        item3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player.quit();
            }
        });
        menu.add(item3);
    }
}
