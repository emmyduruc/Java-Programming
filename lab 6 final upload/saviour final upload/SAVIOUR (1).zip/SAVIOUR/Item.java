
/**
 * Write a description of class Item here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Item
{
    // instance variables - replace the example below with your own
    private String name;

    /**
     * Constructor for objects of class Item
     */
    public Item(String name)
    {
        // initialise instance variables
        this.name= name;
    }
    
    public String getName()
    {
        return name;
    }

   
}
