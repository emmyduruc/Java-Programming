import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.HashSet;
import java.util.Stack;

public class Player implements Playable {

    Game game;
    GuiGame guiGame;


    private Room currentRoom;
    private Stack<Item> inventory = new Stack<Item>();
    private Stack<Room> prevRooms = new Stack<Room>();
    Room firstRoom;

    Player(){
        //instantiate generic game box
        game = Game.getGameInstance();
        //instantiate type of game to play
        guiGame = GuiGame.getGuiGameInstance(this);
    }

    public void play(){
        //create a GUI Frame.... Visible
        guiGame.makeGuiVisible();
        //started game and gets first room
        firstRoom = game.start(this.guiGame);
        //assign first room to current room
        currentRoom = firstRoom;
        //create our stacks/states to maintain current user Room and items
        inventory = new Stack<Item>();
        prevRooms = new Stack<Room>();
    }

    //Central Command Hub --- It understands all games commands 'Playable'
    protected void processCommand(String commandWord, JTextArea displayTextArea)
    {
        if (commandWord.equals("help")) {
            printHelp(displayTextArea);
        }
        else if (commandWord.equals("quit")) {
            this.quitGame();
        }
        else if(commandWord.equals("AK 47") || commandWord.equals("classified information (letter)")){
            takeItem(commandWord, displayTextArea);
        }
        else if(commandWord.equals("back")){
            if(prevRooms.empty()){
                displayTextArea.setText("No room to go back!!!");
            }
            else {
                currentRoom = prevRooms.pop();
                displayTextArea.setText(currentRoom.getLongDescription());
            }
        }
        else{
            goRoom(commandWord, displayTextArea);
        }
    }

    protected void printHelp(JTextArea displayTextArea)
    {
        String commands = "go, quit, help, back, take";
        displayTextArea.setText("You are lost. You are alone. You wander\n"+"around at the university.\n"+"Your command words are:\n"+commands);
    }

    protected void goRoom(String direction, JTextArea displayTextArea)
    {
        // Try to leave current room.
        Room nextRoom = currentRoom.getExit(direction);
        if (nextRoom == null) {
            displayTextArea.setText("There is no door!");
        }
        else {
            String currentState = "";
            prevRooms.push(currentRoom);
            currentRoom = nextRoom;

            if(nextRoom.itemEmptyCheck()==false){
                String items = nextRoom.printAllItem();
                currentState += "Items in the room: "+items+"\n";
                displayTextArea.setText(currentState);
            }
            currentState += currentRoom.getLongDescription();
            displayTextArea.setText(currentState);
        }
    }

    protected void quitGame()
    {
        currentRoom = firstRoom;
        inventory = new Stack<Item>();
        prevRooms = new Stack<Room>();
        firstRoom = game.quit(this.guiGame);
        currentRoom = firstRoom;
    }

    protected void takeItem(String foundItem, JTextArea displayTextArea)
    {
        Item found = currentRoom.findByName(foundItem,currentRoom.getItem());
        if(found != null)
        {
            inventory.push(found);
            displayTextArea.setText("Now you got "+ found.getName()+ "\n\n"+currentRoom.getLongDescription());
        }else{
            displayTextArea.setText("Item: "+foundItem+ " was not found in Room"+"\n\n"+currentRoom.getLongDescription());
        }
    }

    @Override
    public void help() {
        processCommand("help", guiGame.displayTextArea);
    }

    @Override
    public void back() {
        processCommand("back", guiGame.displayTextArea);
    }

    @Override
    public void quit() {
        processCommand("quit", guiGame.displayTextArea);
    }

    @Override
    public void goNorth() {
        processCommand("north", guiGame.displayTextArea);
    }

    @Override
    public void goSouth() {
        processCommand("south", guiGame.displayTextArea);
    }

    @Override
    public void goWest() {
        processCommand("west", guiGame.displayTextArea);
    }

    @Override
    public void goEast() {
        processCommand("east", guiGame.displayTextArea);
    }

    @Override
    public void collectWeapon() {
        processCommand("AK 47", guiGame.displayTextArea);
    }

    @Override
    public void collectLetter() {
        processCommand("classified information (letter)", guiGame.displayTextArea);
    }
}
