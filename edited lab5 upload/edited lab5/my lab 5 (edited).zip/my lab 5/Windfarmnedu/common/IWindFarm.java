package common;


/**
 * Write a description of interface iWindFarm here.
 *
 * @author (Duru Emmanuel)
 * @version (24.05.2020)
 */
public interface IWindFarm
{
    public void print();
    
     public double getOutputCapacity();
     
     public String getCountry();
    
     /*public static String printHeader()
      {
          
        return String.format("| %-20s | %-20s | %-20s | %-20s | %-20s |",  "WindFarm",  "Country", "Capacity", "Number of Turbines", "Year");
        
        
        }
        
     public static String printRuler()
        {
        return String.format("=======================================================================================================");
        } */
        
      
        
      
    
    
}
