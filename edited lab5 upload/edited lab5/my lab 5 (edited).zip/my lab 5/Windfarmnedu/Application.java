import implementation.*;
import common.*;
import client.*;
import java.util.*;

/**
 * Write a description of class Application here.
 *
 * @author (Duru Emmanuel)
 * @version (24.05.2020)
 */
public class Application
{
    public static void initlist()
    {
        WindFarm windFarm1 = new WindFarm("Gemini", "Netherlands",600,150,2017);
        WindFarm windFarm2 = new WindFarm("Thanet", "United Kingdom", 300,100,2010);
        WindFarm windFarm3 = new WindFarm("Walney", "United Kingdom", 659, 116, 2018);
        WindFarm windFarm4 = new WindFarm("Anholt", "Denmark", 400, 111, 2013);
        WindFarm windFarm5 = new WindFarm("Thorntonbank", "Belgium", 325, 48, 2013);
        WindFarmTable windFarmTable1 = new WindFarmTable("kj");
        
        windFarmTable1.addPowerStation(windFarm1);
        windFarmTable1.addPowerStation(windFarm2);
        windFarmTable1.addPowerStation(windFarm3);
        windFarmTable1.addPowerStation(windFarm4);
        windFarmTable1.addPowerStation(windFarm5);
        
        PowerPlant powerPla1= new PowerPlant("Greater Gabbard","United Kingdom",504,140,2012);  
        PowerPlant powerPla2= new PowerPlant("Anholt","Denmark",400,111,2013);
        PowerPlant powerPla3= new PowerPlant("Walney","United Kingdom",659,47,2012);
        PowerPlant powerPla4= new PowerPlant("Gemini","Netherlands",600,150,2017);  
        PowerPlant powerPla5= new PowerPlant("London Array","United Kingdom",630,175,2013);
  
        windFarmTable1.addPowerStation(powerPla1);
        windFarmTable1.addPowerStation(powerPla2);
        windFarmTable1.addPowerStation(powerPla3);
        windFarmTable1.addPowerStation(powerPla4);
        windFarmTable1.addPowerStation(powerPla5);
        
        windFarmTable1.printTable();
    }
    
}
