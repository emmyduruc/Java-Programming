package client;

 import java.util.ArrayList;
 import common.IWindFarm;
/**
 * Write a description of class WildFarmTable here.
 *
 * @author (Duru Emmanuel)
 * @version (24.05.2020)
 */
public class WindFarmTable
{
    // instance variables - replace the example below with your own
    private String name;
    private ArrayList<IWindFarm> windFarms;

    /**
     * Constructor for objects of class WildFarmTable
     */
    public WindFarmTable( String name )
    {
        // initialise instance variables
        this.name = name;;
        windFarms = new ArrayList<IWindFarm>();
        
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void addPowerStation(IWindFarm powerStation)
    {
        windFarms.add(powerStation);
    }
    
    public double getTotalpower()
    {
    double sum = 0;
        for(IWindFarm powerStation : windFarms)
        {
            sum += powerStation.getOutputCapacity();
        }
        return sum;
    }
    
   
   
   public void printTable()
    {
        String Fheader= String.format("| %-66s | %-43s | %-43s |", "Common Variable", "Spec.Variable WindFarm", "Spec.Variable PowerPlant");
        String header = String.format("| %-20s | %-20s | %-20s | %-20s | %-20s | %-20s | %-20s |",  "Names",  "Country", "Capacity", "No. of Turbines", "Year Commission", "Construction Start", "Connection Year");
        String ruler = String.format("==================================================================================================================================================================");
        System.out.println(Fheader);
        System.out.println(header);
        System.out.println(ruler);
        for(IWindFarm powerStation : windFarms)
        {
            powerStation.print();
        }
    
    
    
    }
}











