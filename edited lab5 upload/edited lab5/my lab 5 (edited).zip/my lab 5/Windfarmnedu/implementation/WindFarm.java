package implementation;
import common.IWindFarm;
/**
 * Write a description of class WildFarm here.
 *
 * @author (Duru Emmanuel)
 * @version (24.05.2020)
 */
public class WindFarm implements IWindFarm
{
    // the dwefinition of variables used in this project
    private String name;
    private String country;
    private double capacity;
    private int numberTurbines;
    private int year;
    

    /**
     * Constructor for objects of class WildFarm
     */
    public WindFarm(String name, String country, double capacity, int numberTurbines, int year)
    {
        // initialise instance variables
        this.name = name;
        this.country = country;
        this.capacity = capacity;
        this.numberTurbines = numberTurbines;
        this.year = year;
        
    }
    
    public void print()
    {
        String formtable = String.format( "| %-20s | %-20s | %-20.1f | %-20d | %-20d | %-20s | %-20s | ", name, country, capacity, numberTurbines, year, "-", "-");
        System.out.println (formtable);        
    } 
    
    //to calculate the total power
    public double getOutputCapacity()
    {
        return capacity;
    }
    
    public String getCountry()
    {
    return country;
    }
    

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    
}
