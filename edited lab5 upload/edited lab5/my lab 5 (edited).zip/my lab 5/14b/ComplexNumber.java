
/**
 * Write a description of class ComplexNumber here.
 *
 * @author (Duru Emmanuel)
 * @version (24.05.2020)
 */
public class ComplexNumber
{
    double real;
    double imag;
    
    public ComplexNumber(double real)
    {
        this.real = real;
        this.imag = 0;
    }
    
    
    public ComplexNumber(double real, double imag)
    {
        this.real = real;
        this.imag = imag;
    }
    
    double getReal()
    {
        return this.real;
    }
    
    double getImag()
    {
        return this.imag;
    }
    
    public String toString()
    {
        return "(" + real + "," + imag + ")"; 
    }
    
    ComplexNumber inverse()
    {
        return new ComplexNumber( 1/real , 1/imag );
    }
    
    ComplexNumber multiply(ComplexNumber z)
    {
        return new ComplexNumber( real*z.getReal(), imag*z.getImag() );
    }
    
    
    
    
    
    
    
   
}
