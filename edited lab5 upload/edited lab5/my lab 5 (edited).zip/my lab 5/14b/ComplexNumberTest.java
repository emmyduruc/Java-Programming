

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ComplexNumberTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ComplexNumberTest
{
    /**
     * Default constructor for test class ComplexNumberTest
     */
    public ComplexNumberTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void multi()
    {
        ComplexNumber complexN1 = new ComplexNumber(4, 6);
        ComplexNumber complexN2 = new ComplexNumber(2, 5);
        ComplexNumber complexN3 = complexN2.multiply(complexN1);
        assertEquals("(8.0, 30.0)", complexN3);
    }

    @Test
    public void inverseTest()
    {
        ComplexNumber complexN1 = new ComplexNumber(10, 6);
        ComplexNumber complexN2 = complexN1.inverse();
        assertEquals("(0.1, 0.166666)", complexN2);
    }
}


